from salto.joust import Game
g = Game()
g.run()