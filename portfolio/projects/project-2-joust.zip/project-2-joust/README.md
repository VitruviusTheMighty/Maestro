# Salto - An in-progress game about jumping on platforms

###### Leonardo Ferrisi 23'

## Running:

Run `python play_game.py` in the directory `C://path-to-joust//project-2-joust//`

*or*

Navigate into `C://path-to-joust//project-2-joust//salto` and run `python joust.py`



